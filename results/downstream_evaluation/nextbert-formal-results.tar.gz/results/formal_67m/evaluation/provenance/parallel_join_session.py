"""Adopt completed parallel retrieval runs and join the remaining evaluation results."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time
from typing import Any, Mapping, Sequence

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import run_all_evaluation as evaluation  # noqa: E402

CONTROLLER_PID = 2055650
RETRIEVAL_PIDS = {"V0": 2073081, "V3": 2073413}
POLL_SECONDS = 30


def paths_for(root: Path) -> dict[str, Path]:
    root = root.resolve()
    return {
        "root": root,
        "primary": root / "results" / "formal_67m" / "evaluation",
        "gpu0_v1": root / "results" / "formal_67m" / "evaluation_gpu0_v1",
        "gpu7_v2": root / "results" / "formal_67m" / "evaluation_gpu7_v2",
        "data": root / "data" / "prepared" / "full_67m",
        "model": root / "artifacts" / "mmbert-base",
        "training": root / "results" / "formal_67m",
        "gated": root / "results" / "formal_67m_gatefix",
        "runner": root / "tools" / "run_all_evaluation.py",
    }


def _arg(tokens: Sequence[str], name: str) -> str | None:
    for index, token in enumerate(tokens):
        if token.startswith(name + "="):
            return token.split("=", 1)[1]
        if token == name and index + 1 < len(tokens):
            return tokens[index + 1]
    return None


def build_resume_command(paths: Mapping[str, Path]) -> list[str]:
    return [sys.executable, str(paths["runner"]), "--phase", "tasks", "--variants", "V0,V3",
            "--gpu", "7", "--max-workers", "2", "--output-dir", str(paths["primary"]),
            "--resume", "--execute"]


def _process_row(pid: int) -> dict[str, Any] | None:
    result = subprocess.run(["ps", "-p", str(pid), "-o", "pid=,ppid=,stat=,args="],
                            capture_output=True, text=True, check=False)
    line = result.stdout.strip()
    if not line:
        return None
    parts = line.split(None, 3)
    if len(parts) < 4:
        raise RuntimeError(f"cannot parse ps row for PID {pid}: {line!r}")
    return {"pid": int(parts[0]), "ppid": int(parts[1]), "stat": parts[2], "args": parts[3]}


def _children_rows(pid: int) -> list[dict[str, Any]]:
    result = subprocess.run(["ps", "--ppid", str(pid), "-o", "pid=,ppid=,stat=,args="],
                            capture_output=True, text=True, check=False)
    rows = []
    for line in result.stdout.splitlines():
        parts = line.split(None, 3)
        if len(parts) == 4:
            rows.append({"pid": int(parts[0]), "ppid": int(parts[1]),
                         "stat": parts[2], "args": parts[3]})
    return rows


def _verify_stopped_controller(paths: Mapping[str, Path]) -> None:
    """Validate the stopped parent and ended workers, then TERM+CONT only that parent."""
    controller = _process_row(CONTROLLER_PID)
    if controller is None or not controller["stat"].startswith("T"):
        raise RuntimeError(f"controller PID {CONTROLLER_PID} is not present and stopped")
    tokens = shlex.split(str(controller["args"]))
    if not any(Path(token).name == "run_all_evaluation.py" for token in tokens):
        raise RuntimeError(f"controller PID {CONTROLLER_PID} is not run_all_evaluation.py")
    if _arg(tokens, "--phase") != "tasks" or _arg(tokens, "--gpu") != "7":
        raise RuntimeError(f"controller PID {CONTROLLER_PID} has unexpected phase/GPU arguments")
    if "--execute" not in tokens:
        raise RuntimeError(f"controller PID {CONTROLLER_PID} is not an executing runner")
    output = Path(_arg(tokens, "--output-dir") or (paths["training"] / "evaluation"))
    if not output.is_absolute():
        output = paths["root"] / output
    if output.resolve() != paths["primary"].resolve():
        raise RuntimeError(f"controller PID {CONTROLLER_PID} has unexpected output directory: {output}")

    expected_pids = set(RETRIEVAL_PIDS.values())
    children = _children_rows(CONTROLLER_PID)
    if any(row["pid"] not in expected_pids for row in children):
        raise RuntimeError(f"controller has unexpected children; refusing to signal it: {children}")
    by_pid = {row["pid"]: row for row in children}
    for variant, pid in RETRIEVAL_PIDS.items():
        row = by_pid.get(pid) or _process_row(pid)
        if row is None:
            continue
        if row["ppid"] != CONTROLLER_PID:
            raise RuntimeError(f"retrieval PID {pid} is not a child of controller {CONTROLLER_PID}")
        if row["stat"].startswith("Z"):
            # Reaped child output may display only ``[python] <defunct>``; PPID/PID
            # and the completed raw result/log are sufficient for this zombie.
            continue
        child_args = shlex.split(str(row["args"]))
        if (not any(Path(token).name == "evaluate_nextbert.py" for token in child_args)
                or _arg(child_args, "--task") != "retrieval"
                or _arg(child_args, "--variant") != variant):
            raise RuntimeError(f"PID {pid} does not match the expected {variant} retrieval child")

    for _ in range(30):
        children = _children_rows(CONTROLLER_PID)
        active = [row for row in children if row["pid"] in expected_pids and not row["stat"].startswith("Z")]
        if not active:
            break
        time.sleep(1)
    else:
        raise RuntimeError(f"retrieval children have not exited: {active}")
    if any(row["pid"] not in expected_pids for row in _children_rows(CONTROLLER_PID)):
        raise RuntimeError("controller gained an unexpected child before termination")

    subprocess.run(["kill", "-TERM", str(CONTROLLER_PID)], check=True)
    resume = subprocess.run(["kill", "-CONT", str(CONTROLLER_PID)], check=False)
    if resume.returncode != 0:
        current = _process_row(CONTROLLER_PID)
        if current is not None and not current["stat"].startswith("Z"):
            raise RuntimeError(f"could not SIGCONT controller PID {CONTROLLER_PID}")
    for _ in range(30):
        current = _process_row(CONTROLLER_PID)
        if current is None or current["stat"].startswith("Z"):
            return
        time.sleep(1)
    raise RuntimeError(f"controller PID {CONTROLLER_PID} did not stop after TERM+CONT")


def _read_retrieval_if_ready(status: Mapping[str, Any], variant: str,
                             primary: Path) -> dict[str, Any] | None:
    job_id = f"tasks_{variant}_retrieval_dev_test"
    entry = status.get("jobs", {}).get(job_id)
    if not entry:
        raise RuntimeError(f"primary status has no {job_id}")
    if entry.get("status") == "failed":
        raise RuntimeError(f"primary retrieval job failed: {job_id}")
    log_path = Path(entry["log"])
    raw_path = primary / ".tmp" / f"{variant}_retrieval_source.json"
    if not log_path.is_file() or not raw_path.is_file():
        return None
    log = log_path.read_text(encoding="utf-8", errors="replace")
    if "Traceback (most recent call last)" in log or "__SCHEDULER_ERROR__=" in log:
        raise RuntimeError(f"retrieval log reports failure: {log_path}")
    if '"status": "evaluation_completed"' not in log:
        return None
    try:
        payload = json.loads(raw_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("task") != "retrieval" or payload.get("variant") != variant:
        raise RuntimeError(f"unexpected raw result identity: {raw_path}")
    if payload.get("evaluation_scope") != "prepared_data_scope":
        raise RuntimeError(f"raw result is not full prepared-data scope: {raw_path}")
    return payload


def wait_for_raw_retrievals(status_path: Path, primary: Path) -> dict[str, dict[str, Any]]:
    while True:
        status = json.loads(status_path.read_text(encoding="utf-8"))
        ready = {variant: _read_retrieval_if_ready(status, variant, primary)
                 for variant in RETRIEVAL_PIDS}
        if all(value is not None for value in ready.values()):
            return {variant: value for variant, value in ready.items() if value is not None}
        waiting = [variant for variant, value in ready.items() if value is None]
        print(f"[waiting for primary retrieval results] {waiting}; checking again in {POLL_SECONDS}s", flush=True)
        time.sleep(POLL_SECONDS)


def _write_json_exclusive(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def _write_status(path: Path, state: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(".join.tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def adopt_retrieval_results(paths: Mapping[str, Path], status: dict[str, Any],
                            raw_results: Mapping[str, Mapping[str, Any]]) -> None:
    combined_path = paths["primary"] / "inputs" / "retrieval_queries_dev_test.jsonl"
    for variant in ("V0", "V3"):
        job_id = f"tasks_{variant}_retrieval_dev_test"
        job = next(job for job in evaluation.build_task_jobs(
            model_dir=paths["model"], data_dir=paths["data"], training_dir=paths["training"],
            gated_training_dir=paths["gated"], output_dir=paths["primary"], variants=(variant,)
        ) if job["job_id"] == job_id)
        raw_path = paths["primary"] / ".tmp" / f"{variant}_retrieval_source.json"
        result_path = Path(status["jobs"][job_id]["output"])
        if result_path.resolve() != Path(job["output"]).resolve() or result_path.exists():
            raise FileExistsError(f"unexpected or existing retrieval result target: {result_path}")
        source_map, counts = evaluation.combine_retrieval_queries(
            paths["data"] / "retrieval_queries_dev.jsonl",
            paths["data"] / "retrieval_queries_test.jsonl", combined_path,
        )
        job["data_paths"] = tuple(job["data_paths"]) + (combined_path,)
        aggregated = evaluation.aggregate_retrieval_result(
            raw_results[variant], source_map, counts, variant=variant,
        )
        aggregated["data_files"] = [str(path.resolve()) for path in job["data_paths"]]
        aggregated["checkpoint"] = str(Path(job["checkpoint"]).resolve())
        _write_json_exclusive(result_path, aggregated)
        artifacts = [language["stored_vector_file"] for language in raw_results[variant].get("languages", [])
                     if language.get("stored_vector_file")]
        if not artifacts or any(not Path(artifact).is_file() for artifact in artifacts):
            raise FileNotFoundError(f"retrieval vector artifacts missing for {variant}: {artifacts}")
        entry = status["jobs"][job_id]
        entry["status"] = "succeeded"
        entry["return_code"] = 0
        entry["artifacts"] = artifacts
        _write_status(paths["primary"] / evaluation.STATUS_NAME, status)
        raw_path.unlink()


def wait_for_aux_status(status_path: Path, expected_jobs: set[str]) -> dict[str, Any]:
    while True:
        if not status_path.is_file():
            print(f"[waiting for auxiliary evaluation status] {status_path}; checking again in {POLL_SECONDS}s", flush=True)
            time.sleep(POLL_SECONDS)
            continue
        state = json.loads(status_path.read_text(encoding="utf-8"))
        if state.get("status") == "failed":
            raise RuntimeError(f"auxiliary evaluation failed: {status_path}")
        if state.get("status") == "completed":
            if set(state.get("jobs", {})) != expected_jobs:
                raise RuntimeError(f"auxiliary status job keys differ from expected: {status_path}")
            if any(entry.get("status") != "succeeded" for entry in state["jobs"].values()):
                raise RuntimeError(f"auxiliary evaluation has an unsuccessful job: {status_path}")
            return state
        if state.get("status") not in {"running", "dry_run"}:
            raise RuntimeError(f"unexpected auxiliary status {state.get('status')!r}: {status_path}")
        print(f"[waiting for auxiliary evaluation status] {status_path}; checking again in {POLL_SECONDS}s", flush=True)
        time.sleep(POLL_SECONDS)


def merge_auxiliary_jobs(main_state: dict[str, Any], gpu0_state: Mapping[str, Any],
                         gpu7_state: Mapping[str, Any], finished_utc: str,
                         paths: Mapping[str, Path]) -> None:
    expected = {
        "gpu0_v1": {"tasks_V1_qa_dev", "tasks_V1_qa_test", "tasks_V1_retrieval_dev_test"},
        "gpu7_v2": {"tasks_V2_qa_dev", "tasks_V2_qa_test", "tasks_V2_retrieval_dev_test"},
    }
    pending = {job_id for job_id, entry in main_state["jobs"].items() if entry.get("status") == "pending"}
    if pending != expected["gpu0_v1"] | expected["gpu7_v2"]:
        raise RuntimeError(f"primary pending jobs differ from the six auxiliary jobs: {sorted(pending)}")
    for source_name, source_state, expected_gpu in (("gpu0_v1", gpu0_state, 0), ("gpu7_v2", gpu7_state, 7)):
        if source_state.get("gpu") != expected_gpu:
            raise RuntimeError(f"{source_name} status reports GPU {source_state.get('gpu')}, expected {expected_gpu}")
        incoming = source_state.get("jobs", {})
        if set(incoming) != expected[source_name]:
            raise RuntimeError(f"unexpected job keys in {source_name}: {sorted(incoming)}")
        for job_id, entry in incoming.items():
            if entry.get("status") != "succeeded":
                raise RuntimeError(f"auxiliary job did not succeed: {job_id}")
            for field in ("output", "log"):
                artifact_path = Path(entry[field])
                if not artifact_path.is_absolute():
                    artifact_path = paths["root"] / artifact_path
                try:
                    artifact_path.resolve().relative_to(paths[source_name].resolve())
                except ValueError as exc:
                    raise RuntimeError(f"{source_name} {field} path is outside its output directory: {artifact_path}") from exc
            if job_id not in pending or main_state["jobs"][job_id].get("status") != "pending":
                raise RuntimeError(f"refusing duplicate/failed merge for {job_id}")
            main_state["jobs"][job_id] = entry
    if len(main_state["jobs"]) != 20 or any(entry.get("status") != "succeeded"
                                              for entry in main_state["jobs"].values()):
        raise RuntimeError("primary evaluation is not exactly 20 successful jobs after merge")
    main_state["status"] = "completed"
    main_state["parallel_sources"] = {
        "gpu0_v1": {"status_file": str(paths["gpu0_v1"] / evaluation.STATUS_NAME),
                    "physical_gpu": 0, "jobs": sorted(expected["gpu0_v1"])},
        "gpu7_v2": {"status_file": str(paths["gpu7_v2"] / evaluation.STATUS_NAME),
                    "physical_gpu": 7, "jobs": sorted(expected["gpu7_v2"])},
    }
    main_state["physical_gpus"] = [0, 7]
    main_state["finished_utc"] = finished_utc


def _initial_state_check(status: Mapping[str, Any]) -> None:
    jobs = status.get("jobs", {})
    if len(jobs) != 20:
        raise RuntimeError(f"expected original 20-job status, got {len(jobs)}")
    expected_running = {f"tasks_{variant}_retrieval_dev_test" for variant in ("V0", "V3")}
    expected_pending = {
        *(f"tasks_{variant}_reranking_{split}" for variant in ("V0", "V3") for split in ("dev", "test")),
        "tasks_V1_qa_dev", "tasks_V1_qa_test", "tasks_V1_retrieval_dev_test",
        "tasks_V2_qa_dev", "tasks_V2_qa_test", "tasks_V2_retrieval_dev_test",
    }
    running = {key for key, value in jobs.items() if value.get("status") == "running"}
    pending = {key for key, value in jobs.items() if value.get("status") == "pending"}
    succeeded = {key for key, value in jobs.items() if value.get("status") == "succeeded"}
    if running != expected_running or pending != expected_pending or len(succeeded) != 8:
        raise RuntimeError("primary evaluation status is not the expected 8-succeeded/2-running/10-pending state")


def execute_join(paths: Mapping[str, Path]) -> dict[str, Any]:
    primary_status_path = paths["primary"] / evaluation.STATUS_NAME
    main_state = json.loads(primary_status_path.read_text(encoding="utf-8"))
    _initial_state_check(main_state)
    raw_results = wait_for_raw_retrievals(primary_status_path, paths["primary"])
    _verify_stopped_controller(paths)
    # Re-read status after the child processes and old controller have exited.
    main_state = json.loads(primary_status_path.read_text(encoding="utf-8"))
    _initial_state_check(main_state)
    adopt_retrieval_results(paths, main_state, raw_results)

    command = build_resume_command(paths)
    subprocess.run(command, cwd=paths["root"], check=True)
    main_state = json.loads(primary_status_path.read_text(encoding="utf-8"))
    if any(main_state["jobs"].get(job_id, {}).get("status") != "succeeded"
           for variant in ("V0", "V3")
           for job_id in (f"tasks_{variant}_{task}_{split}"
                          for task in ("classification", "qa", "reranking")
                          for split in ("dev", "test"))):
        raise RuntimeError("V0/V3 evaluation resume did not finish all selected jobs")
    expected_aux = {"tasks_V1_qa_dev", "tasks_V1_qa_test", "tasks_V1_retrieval_dev_test",
                    "tasks_V2_qa_dev", "tasks_V2_qa_test", "tasks_V2_retrieval_dev_test"}
    pending = {key for key, entry in main_state["jobs"].items() if entry.get("status") == "pending"}
    if pending != expected_aux:
        raise RuntimeError(f"primary pending jobs changed unexpectedly: {sorted(pending)}")
    main_state["status"] = "running"
    _write_status(primary_status_path, main_state)

    gpu0 = wait_for_aux_status(paths["gpu0_v1"] / evaluation.STATUS_NAME,
                               {"tasks_V1_qa_dev", "tasks_V1_qa_test", "tasks_V1_retrieval_dev_test"})
    gpu7 = wait_for_aux_status(paths["gpu7_v2"] / evaluation.STATUS_NAME,
                               {"tasks_V2_qa_dev", "tasks_V2_qa_test", "tasks_V2_retrieval_dev_test"})
    merge_auxiliary_jobs(main_state, gpu0, gpu7, datetime.now(timezone.utc).isoformat(), paths)
    _write_status(primary_status_path, main_state)
    return main_state


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="project root")
    parser.add_argument("--execute", action="store_true", help="perform the guarded join; default is dry run")
    args = parser.parse_args(argv)
    paths = paths_for(args.root)
    if not args.execute:
        print(json.dumps({"status": "dry_run", "execute_requires_flag": "--execute",
                          "primary_status": str(paths["primary"] / evaluation.STATUS_NAME),
                          "raw_retrieval_results": [str(paths["primary"] / ".tmp" / f"{variant}_retrieval_source.json")
                                                     for variant in ("V0", "V3")],
                          "controller_pid": CONTROLLER_PID, "retrieval_child_pids": RETRIEVAL_PIDS,
                          "resume_command": shlex.join(build_resume_command(paths)),
                          "auxiliary_statuses": [str(paths[name] / evaluation.STATUS_NAME)
                                                 for name in ("gpu0_v1", "gpu7_v2")]},
                         ensure_ascii=False, indent=2))
        return 0
    state = execute_join(paths)
    print(json.dumps({"status": state["status"], "completed_jobs": len(state["jobs"]),
                      "physical_gpus": state["physical_gpus"],
                      "status_file": str(paths["primary"] / evaluation.STATUS_NAME)},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
